var HeightTela=$(window).height();
$('.video')